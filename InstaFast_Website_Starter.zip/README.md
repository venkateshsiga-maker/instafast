# InstaFast website starter

A responsive website starter with a Node.js/Express backend.

## Run locally
1. Install Node.js 18 or later.
2. In this folder run: `npm install`
3. Run: `npm start`
4. Open `http://localhost:3000`

## Publish
- Deploy this whole project (not just `public/`) to a Node.js host such as Render.
- Set the build command to `npm install` and start command to `npm start`.
- Add a custom domain in your hosting dashboard if desired.
- Netlify static drag-and-drop alone will not run this Express backend.

## Important functionality note
The UI and server starter are included, but Instagram media resolution/download is intentionally not enabled. The `/api/resolve` endpoint validates Instagram URLs and returns an explanatory message. To activate processing, integrate an official/authorized API that permits the intended use. Do not scrape private content, collect passwords, or bypass platform access controls. The website is not affiliated with Instagram or Meta.

Before public launch, customize the Privacy, Terms, and Contact pages; add a real support contact; configure HTTPS; and review applicable laws and platform terms.
