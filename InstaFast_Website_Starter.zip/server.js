const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/resolve", (req, res) => {
  const url = String(req.body?.url || "").trim();
  if (!url) return res.status(400).json({ error: "Paste a link first." });

  let parsed;
  try { parsed = new URL(url); }
  catch { return res.status(400).json({ error: "Please enter a valid URL." }); }

  const allowedHosts = ["instagram.com", "www.instagram.com"];
  if (!allowedHosts.includes(parsed.hostname)) {
    return res.status(400).json({ error: "Please enter an Instagram link." });
  }

  // Safe integration point:
  // Connect an authorized Meta/Instagram API or a provider that has permission
  // to process the content. Do not scrape private content or bypass login,
  // access controls, rate limits, or platform protections.
  return res.status(501).json({
    error: "Instagram media processing is not connected yet.",
    detail: "This starter site is ready for an authorized API integration. Download only content you own or have permission to save."
  });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`InstaFast running on port ${PORT}`));