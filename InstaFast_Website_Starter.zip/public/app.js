const tabs = document.querySelectorAll(".tab");
const label = document.getElementById("inputLabel");
const input = document.getElementById("urlInput");
const message = document.getElementById("message");
const submit = document.getElementById("submitBtn");
let kind = "Reel";
const placeholders = {
  Reel: "https://www.instagram.com/reel/...",
  Video: "https://www.instagram.com/p/...",
  Photo: "https://www.instagram.com/p/...",
  Profile: "https://www.instagram.com/username/"
};
tabs.forEach(tab => tab.addEventListener("click", () => {
  tabs.forEach(t => t.classList.remove("active"));
  tab.classList.add("active");
  kind = tab.dataset.kind;
  label.textContent = `Instagram ${kind} link`;
  input.placeholder = placeholders[kind];
  message.textContent = "";
}));
document.getElementById("pasteBtn").addEventListener("click", async () => {
  try { input.value = await navigator.clipboard.readText(); message.textContent = "Link pasted."; }
  catch { message.textContent = "Clipboard access unavailable. Long-press the box and choose Paste."; }
});
submit.addEventListener("click", async () => {
  message.textContent = "";
  if (!input.value.trim()) { message.textContent = "Please paste an Instagram link."; return; }
  submit.disabled = true; submit.textContent = "Checking link…";
  try {
    const response = await fetch("/api/resolve", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({url: input.value.trim(), kind})
    });
    const result = await response.json();
    message.textContent = result.detail || result.error || "Unable to process this link.";
  } catch {
    message.textContent = "Could not reach the server. Please try again later.";
  } finally { submit.disabled = false; submit.innerHTML = 'Continue <span>→</span>'; }
});
document.getElementById("year").textContent = new Date().getFullYear();